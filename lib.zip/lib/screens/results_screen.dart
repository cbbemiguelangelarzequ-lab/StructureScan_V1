// lib/screens/results_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class ResultsScreen extends StatefulWidget {
  final List<String> analyzedImages;

  const ResultsScreen({super.key, required this.analyzedImages});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  int _currentImageIndex = 0;

  // Datos simulados para diferentes tipos de defectos
  final List<List<Map<String, dynamic>>> _simulatedDefects = [
    // Defectos para Imagen 1
    [
      {'type': 'grieta_lineal', 'severity': 'leve', 'position': 'superior izq', 'description': 'Pequeña fisura superficial en el revoque.'},
      {'type': 'humedad_mancha', 'severity': 'moderada', 'position': 'inferior centro', 'description': 'Mancha de humedad con posible moho en la base del muro.'},
    ],
    // Defectos para Imagen 2
    [
      {'type': 'grieta_capilar', 'severity': 'leve', 'position': 'inferior der', 'description': 'Red de microfisuras.'},
      {'type': 'imperfeccion_desconchado', 'severity': 'moderada', 'position': 'centro', 'description': 'Área de pintura o revoque desconchada.'},
    ],
    // Defectos para Imagen 3
    [
      {'type': 'grieta_estructural', 'severity': 'severa', 'position': 'superior der', 'description': 'Grieta diagonal indicando posible problema estructural.'},
      {'type': 'desnivel_muro', 'severity': 'severa', 'position': 'lado izquierdo', 'description': 'Claro desnivel vertical en la superficie del muro.'},
      {'type': 'humedad_eflorescencia', 'severity': 'leve', 'position': 'inferior izq', 'description': 'Presencia de sales blanquecinas por humedad.'},
    ],
    // Puedes añadir más conjuntos de defectos para cada imagen si hay más imágenes analizadas
  ];

  // Controlador para el campo de texto de la observación manual
  final TextEditingController _manualObservationController = TextEditingController();

  @override
  void dispose() {
    _manualObservationController.dispose();
    super.dispose();
  }

  // Helper function to get color based on severity
  Color _getSeverityColor(String severity) {
    switch (severity) {
      case 'leve':
        return kVerdeExito;
      case 'moderada':
        return kNaranjaAcento;
      case 'severa':
        return kRojoAdvertencia;
      default:
        return kGrisMedio; // Default color for unknown severity
    }
  }

  // Helper function to get icon based on severity
  IconData _getSeverityIcon(String severity) {
    switch (severity) {
      case 'leve':
        return Icons.check_circle_outline;
      case 'moderada':
        return Icons.warning_amber_outlined;
      case 'severa':
        return Icons.error_outline;
      default:
        return Icons.info_outline; // Default icon for unknown severity
    }
  }

  // Helper function to get a user-friendly name for defect types
  String _getDefectTypeName(String type) {
    switch (type) {
      case 'grieta_lineal':
        return 'Grieta Lineal';
      case 'grieta_ramificada':
        return 'Grieta Ramificada';
      case 'grieta_capilar':
        return 'Grieta Capilar';
      case 'grieta_estructural':
        return 'Grieta Estructural';
      case 'grieta_fisura':
        return 'Fisura';
      case 'humedad_mancha':
        return 'Humedad (Mancha)';
      case 'humedad_eflorescencia':
        return 'Humedad (Eflorescencia)';
      case 'imperfeccion_desconchado':
        return 'Desconchado';
      case 'desnivel_muro':
        return 'Desnivel de Muro';
      default:
        return type.replaceAll('_', ' ').toCapitalized(); // Fallback for new types
    }
  }

  // Nueva función para añadir observación manual
  void _addManualObservation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Añadir Observación Manual'),
          content: TextField(
            controller: _manualObservationController,
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'Escribe tu observación aquí...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              filled: true,
              fillColor: kGrisClaro,
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancelar', style: TextStyle(color: kGrisOscuro)),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _manualObservationController.clear(); // Limpiar el campo
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kAzulPrincipalOscuro,
              ),
              child: Text('Guardar', style: TextStyle(color: kBlanco)),
              onPressed: () {
                final observation = _manualObservationController.text.trim();
                if (observation.isNotEmpty) {
                  // Aquí es donde procesarías la observación
                  // En una aplicación real, la guardarías en tu modelo de datos
                  // asociada a la imagen actual o a la inspección.
                  print('Observación Manual Guardada para Imagen #${_currentImageIndex + 1}: $observation');
                  // Puedes añadir un SnackBar para confirmar al usuario
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Observación guardada: "$observation"'),
                      backgroundColor: kVerdeExito,
                    ),
                  );
                }
                Navigator.of(dialogContext).pop();
                _manualObservationController.clear(); // Limpiar el campo después de guardar
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentDefects = _currentImageIndex < _simulatedDefects.length
        ? _simulatedDefects[_currentImageIndex]
        : [];

    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Resultados del Análisis', style: kTituloPrincipalStyle),
        actions: [
          IconButton(
            icon: const Icon(Icons.share, color: kBlanco),
            onPressed: () {
              print('Compartir resultados');
            },
          ),
          IconButton(
            icon: const Icon(Icons.more_vert, color: kBlanco),
            onPressed: () {
              print('Más opciones');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            flex: 2,
            child: Stack(
              children: [
                Container(
                  color: Colors.black,
                  alignment: Alignment.center,
                  child: Text(
                    'IMAGEN ANALIZADA\n#${_currentImageIndex + 1}',
                    textAlign: TextAlign.center,
                    style: kTituloPrincipalStyle.copyWith(color: kBlanco.withAlpha((0.5 * 255).round())),
                  ),
                ),
                ...currentDefects.map((defect) {
                  return Positioned(
                    top: (MediaQuery.of(context).size.height / 5) * (1 + _simulatedDefects[_currentImageIndex].indexOf(defect) * 0.5) % (MediaQuery.of(context).size.height / 2),
                    left: (MediaQuery.of(context).size.width / 4) * (1 + _simulatedDefects[_currentImageIndex].indexOf(defect) * 0.3) % (MediaQuery.of(context).size.width / 2),
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        color: _getSeverityColor(defect['severity']).withAlpha((0.6 * 255).round()),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: _getSeverityColor(defect['severity']), width: 2),
                      ),
                      child: Text(
                        '${_getDefectTypeName(defect['type']).toUpperCase()} \n(${defect['severity'].toUpperCase()})',
                        style: kMiniaturaTextStyle.copyWith(color: kBlanco, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }).toList(),
                if (widget.analyzedImages.length > 1)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 10,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(widget.analyzedImages.length, (index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _currentImageIndex = index;
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4.0),
                            width: _currentImageIndex == index ? 10.0 : 8.0,
                            height: _currentImageIndex == index ? 10.0 : 8.0,
                            decoration: BoxDecoration(
                              color: _currentImageIndex == index ? kNaranjaAcento : kGrisMedio.withAlpha((0.5 * 255).round()),
                              shape: BoxShape.circle,
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              child: Container(
                color: kBlanco,
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Resumen de Defectos Detectados:',
                      style: kTituloPantallaStyle.copyWith(fontSize: 18, color: kAzulPrincipalOscuro),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 10.0,
                      runSpacing: 10.0,
                      children: [
                        _buildSummaryChip('Leves', currentDefects.where((d) => d['severity'] == 'leve').length, kVerdeExito),
                        _buildSummaryChip('Moderadas', currentDefects.where((d) => d['severity'] == 'moderada').length, kNaranjaAcento),
                        _buildSummaryChip('Severas', currentDefects.where((d) => d['severity'] == 'severa').length, kRojoAdvertencia),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () {
                            _addManualObservation(context); // Llama a la nueva función
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kAzulSecundarioClaro,
                            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          icon: const Icon(Icons.add_comment, color: kBlanco),
                          label: Text('Obs. Manual', style: kButtonTextStyle.copyWith(fontSize: 14)),
                        ),
                        ElevatedButton.icon(
                          onPressed: () {
                            print('Generar Informe');
                            Navigator.of(context).pushNamed('/reports', arguments: _simulatedDefects);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kAzulPrincipalOscuro,
                            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          icon: const Icon(Icons.description, color: kBlanco),
                          label: Text('Generar Informe', style: kButtonTextStyle.copyWith(fontSize: 14)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryChip(String label, int count, Color color) {
    return Chip(
      backgroundColor: color.withAlpha((0.15 * 255).round()),
      label: Text(
        '$label: $count',
        style: kBodyTextStyle.copyWith(color: color, fontWeight: FontWeight.bold, fontSize: 14),
      ),
      avatar: Icon(_getSeverityIcon(label.toLowerCase()), color: color, size: 18),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: color, width: 1)),
    );
  }
}

// Extensión para capitalizar la primera letra de una cadena y reemplazar guiones bajos
extension StringCasingExtension on String {
  String toCapitalized() => length > 0 ? '${this[0].toUpperCase()}${substring(1).toLowerCase()}' : '';
  String toTitleCase() => replaceAll(RegExp(' +'), ' ').split(' ').map((str) => str.toCapitalized()).join(' ');
}