// lib/screens/projects_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class ProjectsScreen extends StatefulWidget { // Cambiamos a StatefulWidget para usar TextEditingController
  const ProjectsScreen({super.key});

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  final TextEditingController _projectNameController = TextEditingController(); // Controlador para el nombre del proyecto

  @override
  void dispose() {
    _projectNameController.dispose();
    super.dispose();
  }

  void _createNewProject(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Crear Nuevo Proyecto'),
          content: TextField(
            controller: _projectNameController,
            decoration: InputDecoration(
              hintText: 'Nombre del Proyecto',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              filled: true,
              fillColor: kGrisClaro,
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancelar', style: TextStyle(color: kGrisOscuro)),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _projectNameController.clear(); // Limpiar el campo
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kAzulPrincipalOscuro,
              ),
              child: Text('Crear', style: TextStyle(color: kBlanco)),
              onPressed: () {
                final projectName = _projectNameController.text.trim();
                if (projectName.isNotEmpty) {
                  // Aquí se implementaría la lógica real para crear un proyecto.
                  // Por ahora, solo simulamos la creación.
                  print('Proyecto "$projectName" creado exitosamente.');
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Proyecto "$projectName" creado con éxito!'),
                      backgroundColor: kVerdeExito,
                    ),
                  );
                }
                Navigator.of(dialogContext).pop();
                _projectNameController.clear(); // Limpiar el campo después de crear
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Mis Proyectos', style: kTituloPrincipalStyle),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kBlanco),
          onPressed: () {
            if (Navigator.of(context).canPop()) {
              Navigator.of(context).pop();
            } else {
              Navigator.of(context).pushReplacementNamed('/dashboard');
            }
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.home, color: kBlanco),
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Listado de Proyectos Activos',
              style: kTituloPantallaStyle.copyWith(fontSize: 20, color: kAzulPrincipalOscuro),
            ),
            const SizedBox(height: 15),
            Expanded(
              child: ListView.builder(
                itemCount: 3, // Simulated projects
                itemBuilder: (context, index) {
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    elevation: 2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    child: ListTile(
                      leading: Icon(Icons.folder_open, color: kAzulSecundarioClaro),
                      title: Text('Proyecto Edificio ${index + 1}', style: kBodyTextStyle.copyWith(fontWeight: FontWeight.bold)),
                      subtitle: Text('Estado: Activo\nÚltima Actualización: 2025-06-${10 + index}', style: kMiniaturaTextStyle),
                      trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kGrisMedio),
                      onTap: () {
                        print('Ver detalles del Proyecto Edificio ${index + 1}');
                      },
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  _createNewProject(context); // Llama a la nueva función
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kNaranjaAcento,
                  padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                icon: const Icon(Icons.add, color: kBlanco),
                label: Text('Crear Nuevo Proyecto', style: kButtonTextStyle),
              ),
            ),
          ],
        ),
      ),
    );
  }
}