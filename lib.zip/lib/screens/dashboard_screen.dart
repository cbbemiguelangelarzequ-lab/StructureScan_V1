// lib/screens/dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';
import 'package:structurescan_app/screens/inspections_screen.dart';
import 'package:structurescan_app/screens/reports_screen.dart';
import 'package:structurescan_app/screens/profile_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // Importa el paquete de Supabase

class DashboardScreen extends StatefulWidget {
  // El constructor ya no necesita 'userName' porque se carga dinámicamente.
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  String _displayedUserName = 'Cargando...'; // Estado para el nombre del usuario

  @override
  void initState() {
    super.initState();
    _loadUserProfile(); // Llama a la función para cargar el perfil al inicio.
  }

  Future<void> _loadUserProfile() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      print('DEBUG: Usuario autenticado: ${user?.email ?? "NULO"} (ID: ${user?.id ?? "NULO"})'); // DEBUG
      if (user != null) {
        // Realiza la consulta a la tabla 'profiles' para obtener el 'full_name' del usuario actual.
        final response = await Supabase.instance.client
            .from('profiles')
            .select('full_name') // Selecciona solo la columna 'full_name'.
            .eq('id', user.id) // Filtra por el ID del usuario autenticado.
            .single(); // Espera un único resultado.

        print('DEBUG: Respuesta de Supabase para perfil: $response'); // DEBUG

        // Eliminado: la comprobación 'response != null' ya no es necesaria y causaba la advertencia.
        // Ahora solo verificamos si 'full_name' dentro de la respuesta es nulo.
        if (response['full_name'] != null) {
          setState(() {
            _displayedUserName = response['full_name'] as String;
          });
          print('DEBUG: Nombre de usuario actualizado a: $_displayedUserName'); // DEBUG
        } else {
          // Si 'full_name' es null en la base de datos, usa un valor por defecto.
          setState(() {
            _displayedUserName = 'Usuario';
          });
          print('DEBUG: full_name es NULO en la base de datos. Mostrando: $_displayedUserName'); // DEBUG
        }
      } else {
        // Si no hay un usuario logeado, usa un valor por defecto.
        setState(() {
          _displayedUserName = 'Usuario';
        });
        print('DEBUG: No hay usuario logeado. Mostrando: $_displayedUserName'); // DEBUG
      }
    } catch (e) {
      // Captura cualquier error que ocurra durante la carga del perfil.
      print('ERROR: Error al cargar el perfil del usuario: $e'); // Para depuración.
      setState(() {
        _displayedUserName = 'Usuario'; // En caso de error, muestra "Usuario".
      });
    }
  }

  void _changeBottomNavItem(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> widgetOptions = <Widget>[
      DashboardContent(onNavigateToTab: _changeBottomNavItem),
      const InspectionsScreen(),
      const ReportsScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text(
          'Hola, $_displayedUserName', // Muestra el nombre de usuario cargado.
          style: kTituloPrincipalStyle.copyWith(fontSize: 22.0), // Ajuste de estilo para que coincida con la imagen
        ),
        actions: const [
          Icon(Icons.notifications, color: kBlanco),
          SizedBox(width: 15),
          Icon(Icons.account_circle, color: kBlanco),
          SizedBox(width: 15),
        ],
      ),
      backgroundColor: kGrisClaro,
      body: widgetOptions.elementAt(_selectedIndex),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          print("Iniciar Nueva Inspección");
          Navigator.of(context).pushNamed('/new_inspection_camera');
        },
        backgroundColor: kNaranjaAcento,
        child: const Icon(Icons.camera_alt, color: kBlanco),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            activeIcon: Icon(Icons.home, color: kAzulSecundarioClaro),
            label: 'Inicio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            activeIcon: Icon(Icons.search, color: kAzulSecundarioClaro),
            label: 'Inspecciones',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.description_outlined),
            activeIcon: Icon(Icons.description, color: kAzulSecundarioClaro),
            label: 'Informes',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person, color: kAzulSecundarioClaro),
            label: 'Perfil',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: kAzulPrincipalOscuro,
        unselectedItemColor: kGrisMedio,
        onTap: _changeBottomNavItem,
        backgroundColor: kBlanco,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: kMiniaturaTextStyle.copyWith(fontWeight: FontWeight.bold),
        unselectedLabelStyle: kMiniaturaTextStyle,
      ),
    );
  }
}

class DashboardContent extends StatelessWidget {
  final ValueSetter<int> onNavigateToTab;

  const DashboardContent({super.key, required this.onNavigateToTab});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            color: kBlanco,
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '¡Bienvenido a StructureScan!',
                    style: kSaludoDashboardStyle.copyWith(fontSize: 20),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Tu aliado para la seguridad estructural.',
                    style: kBodyTextStyle.copyWith(color: kGrisOscuro, fontSize: 14),
                  ),
                  const SizedBox(height: 15),
                  Row(
                    children: [
                      Icon(Icons.calendar_today, size: 18, color: kAzulSecundarioClaro),
                      SizedBox(width: 8),
                      Text('Última inspección: Casa García, 12/06/2025', style: kMiniaturaTextStyle),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.pending_actions, size: 18, color: kNaranjaAcento),
                      SizedBox(width: 8),
                      Text('2 informes pendientes de revisión', style: kMiniaturaTextStyle.copyWith(color: kNaranjaAcento)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 25),

          Text(
            'Acciones Rápidas',
            style: kTituloPantallaStyle.copyWith(fontSize: 20, color: kAzulPrincipalOscuro),
          ),
          const SizedBox(height: 15),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            children: [
              _buildQuickActionButton(
                context,
                icon: Icons.search,
                label: 'Ver Inspecciones',
                onTap: () {
                  onNavigateToTab(1); // Navega a InspectionsScreen.
                },
              ),
              _buildQuickActionButton(
                context,
                icon: Icons.description,
                label: 'Ver Informes',
                onTap: () {
                  onNavigateToTab(2); // Navega a ReportsScreen.
                },
              ),
              _buildQuickActionButton(
                context,
                icon: Icons.build,
                label: 'Mis Proyectos',
                onTap: () {
                  print('Navegar a Mis Proyectos');
                  Navigator.of(context).pushNamed('/projects'); // Navega a ProjectsScreen.
                },
              ),
              _buildQuickActionButton(
                context,
                icon: Icons.help_outline,
                label: 'Ayuda',
                onTap: () {
                  print('Navegar a Ayuda');
                  Navigator.of(context).pushNamed('/help'); // Navega a HelpScreen.
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton(BuildContext context, {required IconData icon, required String label, required VoidCallback onTap}) {
    return Card(
      color: kBlanco,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: kAzulSecundarioClaro),
            const SizedBox(height: 10),
            Text(
              label,
              textAlign: TextAlign.center,
              style: kBodyTextStyle.copyWith(fontWeight: FontWeight.w500, color: kAzulPrincipalOscuro),
            ),
          ],
        ),
      ),
    );
  }
}