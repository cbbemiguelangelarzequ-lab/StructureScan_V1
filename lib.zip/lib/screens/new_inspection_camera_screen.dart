// lib/screens/new_inspection_camera_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class NewInspectionCameraScreen extends StatefulWidget {
  const NewInspectionCameraScreen({super.key});

  @override
  State<NewInspectionCameraScreen> createState() => _NewInspectionCameraScreenState();
}

class _NewInspectionCameraScreenState extends State<NewInspectionCameraScreen> {
  final List<String> _capturedImages = [];
  int _imageCounter = 0;

  void _takePicture() {
    setState(() {
      _imageCounter++;
      _capturedImages.add('simulated_image_${_imageCounter}.png');
      print('Foto simulada ${_imageCounter} tomada.');
    });
  }

  void _navigateToReviewScreen() {
    if (_capturedImages.isNotEmpty) {
      Navigator.of(context).pushNamed(
        '/review_images',
        arguments: _capturedImages,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, toma al menos una foto.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Center(
            child: Icon(
              Icons.photo_camera_back,
              color: Colors.white.withAlpha((0.3 * 255).round()), // Using withAlpha
              size: 200,
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AppBar(
              backgroundColor: kAzulPrincipalOscuro.withAlpha((0.8 * 255).round()), // Using withAlpha
              elevation: 0,
              title: Text(
                'Nueva Inspección',
                style: kTituloPrincipalStyle.copyWith(fontSize: 20),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.flash_on, color: kBlanco),
                  onPressed: () { /* Lógica de flash */ },
                ),
                IconButton(
                  icon: const Icon(Icons.settings, color: kBlanco),
                  onPressed: () { /* Lógica de ajustes */ },
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: kBlanco),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ),
          ),
          Positioned(
            top: AppBar().preferredSize.height + 10,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                decoration: BoxDecoration(
                  color: kGrisClaro.withAlpha((0.8 * 255).round()), // Using withAlpha
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'Enfoca el área a inspeccionar y toma fotos.',
                  style: kBodyTextStyle.copyWith(color: kAzulPrincipalOscuro, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withAlpha((0.6 * 255).round()), // Using withAlpha
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: _navigateToReviewScreen,
                        child: Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            border: Border.all(color: kAzulSecundarioClaro, width: 2),
                            borderRadius: BorderRadius.circular(8),
                            color: kGrisMedio,
                          ),
                          child: _capturedImages.isNotEmpty
                              ? Center(
                                  child: Text(
                                    '${_capturedImages.length} fotos',
                                    style: kMiniaturaTextStyle.copyWith(color: kBlanco),
                                    textAlign: TextAlign.center,
                                  ),
                                )
                              : const Icon(Icons.photo_library, color: kBlanco, size: 30),
                        ),
                      ),
                      FloatingActionButton(
                        onPressed: _takePicture,
                        backgroundColor: kNaranjaAcento,
                        elevation: 0,
                        child: const Icon(Icons.camera, color: kBlanco, size: 35),
                      ),
                      ElevatedButton(
                        onPressed: _navigateToReviewScreen,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kAzulSecundarioClaro,
                          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          elevation: 0,
                        ),
                        child: Text(
                          _capturedImages.isEmpty ? 'Finalizar' : 'Revisar Fotos (${_capturedImages.length})',
                          style: kButtonTextStyle.copyWith(fontSize: 14),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}