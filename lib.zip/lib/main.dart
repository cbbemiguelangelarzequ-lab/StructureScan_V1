import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // Importa Supabase

// Importaciones pantallas 
import 'package:structurescan_app/screens/splash_screen.dart';
import 'package:structurescan_app/screens/onboarding_screen.dart';
import 'package:structurescan_app/screens/auth_screen.dart';
import 'package:structurescan_app/screens/dashboard_screen.dart';
import 'package:structurescan_app/screens/inspections_screen.dart';
import 'package:structurescan_app/screens/new_inspection_camera_screen.dart';
import 'package:structurescan_app/screens/review_images_screen.dart';
import 'package:structurescan_app/screens/analysis_screen.dart';
import 'package:structurescan_app/screens/results_screen.dart';
import 'package:structurescan_app/screens/reports_screen.dart';
import 'package:structurescan_app/screens/pdf_export_screen.dart';
import 'package:structurescan_app/screens/profile_screen.dart';
import 'package:structurescan_app/screens/settings_screen.dart';
import 'package:structurescan_app/screens/projects_screen.dart';
import 'package:structurescan_app/screens/help_screen.dart';
import 'package:structurescan_app/constants.dart';
  

// Función principal asíncrona para inicializar Supabase
Future<void> main() async {
  // Asegura que los widgets de Flutter estén inicializados antes de cualquier operación asíncrona
  WidgetsFlutterBinding.ensureInitialized();


  const String supabaseUrl = 'https://fsrlsiauzjatnujjsfri.supabase.co'; 
  const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzcmxzaWF1emphdG51ampzZnJpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAxMDk1MzAsImV4cCI6MjA2NTY4NTUzMH0.GKIWa3OjXH7_1jDNzoqPE62JQqYEJfdPgv7wjxKyEbI'; // Ej: 'eyJ...etc. TU CLAVE LARGA AQUI'

  // Inicializa Supabase
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
    // Puedes añadir opciones adicionales si es necesario, por ejemplo, para almacenamiento
    // storage: SupabaseStorageOptions(
    //   debug: true, // Habilita logs de depuración para Storage
    // ),
  );

  // Una vez inicializado Supabase, ejecuta tu aplicación Flutter
  runApp(const MyApp());
}

// Puedes acceder a la instancia de Supabase en cualquier parte de tu aplicación
// declarándola a nivel global o pasándola como parte de la herencia de widgets.
// Esta es una forma común de hacerlo para acceso global.
final SupabaseClient supabase = Supabase.instance.client;


// Tu widget principal MyApp (definición existente)
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StructureScan App',
      debugShowCheckedModeBanner: false, // Puedes mantener esto o quitarlo
      theme: ThemeData(
        // Asegúrate de usar tus constantes de color aquí, si no lo haces ya
        primaryColor: kAzulPrincipalOscuro,
        hintColor: kAzulSecundarioClaro,
        scaffoldBackgroundColor: kGrisClaro,
        appBarTheme: const AppBarTheme(
          backgroundColor: kAzulPrincipalOscuro,
          elevation: 0,
        ),
        // Puedes definir otras propiedades del tema si lo deseas
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/auth': (context) => const AuthScreen(),
        '/dashboard': (context) => const DashboardScreen(),
        // Las siguientes pantallas ya no necesitan Scaffold ni AppBar si son pestañas del Dashboard
        '/inspections': (context) => const InspectionsScreen(),
        '/new_inspection_camera': (context) => const NewInspectionCameraScreen(),
        '/review_images': (context) {
          final args = ModalRoute.of(context)?.settings.arguments as List<String>?;
          // Asegúrate de que ReviewImagesScreen espera 'imagePaths' o 'capturedImages'
          return ReviewImagesScreen(imagePaths: args ?? []);
        },
        '/analysis': (context) {
          final args = ModalRoute.of(context)?.settings.arguments as List<String>?;
          return AnalysisScreen(imagesToAnalyze: args ?? []);
        },
        '/results': (context) {
          final args = ModalRoute.of(context)?.settings.arguments as List<String>?;
          return ResultsScreen(analyzedImages: args ?? []);
        },
        // Las siguientes pantallas ya no necesitan Scaffold ni AppBar si son pestañas del Dashboard
        '/reports': (context) => const ReportsScreen(),
        '/pdf_export_screen': (context) {
          final args = ModalRoute.of(context)?.settings.arguments as String?;
          return PdfExportScreen(reportTitle: args ?? 'Informe Detallado');
        },
        // La pantalla de perfil también es ahora una pestaña del Dashboard
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/projects': (context) => const ProjectsScreen(),
        '/help': (context) => const HelpScreen(),
      },
    );
  }
}