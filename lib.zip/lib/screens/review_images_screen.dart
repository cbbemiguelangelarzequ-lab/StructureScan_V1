import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart'; // Asegúrate de que tus constantes estén importadas

class ReviewImagesScreen extends StatefulWidget {
  // Asegúrate de que este sea el nombre correcto del parámetro que esperas
  final List<String> imagePaths; // Es 'final', por lo que debe ser inicializado correctamente

  // El constructor debe inicializar 'imagePaths'
  const ReviewImagesScreen({super.key, required this.imagePaths}); // <-- ¡Asegúrate de que sea así!

  @override
  State<ReviewImagesScreen> createState() => _ReviewImagesScreenState();
}

class _ReviewImagesScreenState extends State<ReviewImagesScreen> {
  late List<String> _currentImages;

  @override
  void initState() {
    super.initState();
    // Inicializa _currentImages con las imagePaths pasadas al widget
    _currentImages = List.from(widget.imagePaths);
  }

  void _removeImage(int index) {
    setState(() {
      _currentImages.removeAt(index);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Imagen eliminada.'),
          backgroundColor: kRojoAdvertencia,
        ),
      );
    });
  }

  void _addMorePhotos() {
    print('Añadir más fotos');
    setState(() {
      _currentImages.add('IMG ${_currentImages.length + 1}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Simulando añadir más fotos.'),
          backgroundColor: kAzulSecundarioClaro,
        ),
      );
    });
  }

  void _continueToAnalysis() {
    if (_currentImages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Por favor, añade al menos una foto para continuar.'),
          backgroundColor: kRojoAdvertencia,
        ),
      );
      return;
    }
    print('Continuar al Análisis con ${_currentImages.length} fotos');
    Navigator.of(context).pushNamed(
      '/analysis', // Cambiado a '/analysis' según tu flujo
      arguments: _currentImages,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Revisar Fotos (${_currentImages.length})', style: kTituloPrincipalStyle),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kBlanco),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.home, color: kBlanco),
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _currentImages.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.photo_library_outlined, size: 80, color: kGrisMedio),
                        const SizedBox(height: 20),
                        Text('No hay fotos seleccionadas.', style: kBodyTextStyle.copyWith(color: kGrisMedio)),
                        const SizedBox(height: 20),
                        ElevatedButton.icon(
                          onPressed: _addMorePhotos,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kAzulSecundarioClaro,
                            padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                          icon: const Icon(Icons.add_a_photo, color: kBlanco),
                          label: Text('Añadir Fotos', style: kButtonTextStyle),
                        ),
                      ],
                    ),
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(16.0),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10.0,
                      mainAxisSpacing: 10.0,
                      childAspectRatio: 1.0,
                    ),
                    itemCount: _currentImages.length,
                    itemBuilder: (context, index) {
                      final imagePath = _currentImages[index];
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        elevation: 3,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            Container(
                              color: kGrisMedio.withOpacity(0.2),
                              alignment: Alignment.center,
                              child: Text(
                                imagePath,
                                style: kBodyTextStyle.copyWith(color: kGrisOscuro),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            Positioned(
                              top: 5,
                              right: 5,
                              child: GestureDetector(
                                onTap: () => _removeImage(index),
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: kRojoAdvertencia,
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(Icons.close, color: kBlanco, size: 18),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _addMorePhotos,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kAzulSecundarioClaro,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.camera_alt, color: kBlanco),
                    label: Text('Añadir más fotos', style: kButtonTextStyle.copyWith(fontSize: 14)),
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _continueToAnalysis,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kAzulPrincipalOscuro,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.bar_chart, color: kBlanco),
                    label: Text('Continuar Análisis', style: kButtonTextStyle.copyWith(fontSize: 14)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}