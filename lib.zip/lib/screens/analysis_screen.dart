// lib/screens/analysis_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';
import 'dart:async';

class AnalysisScreen extends StatefulWidget {
  final List<String> imagesToAnalyze;

  const AnalysisScreen({super.key, required this.imagesToAnalyze});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 4), () {
      Navigator.of(context).pushReplacementNamed(
        '/results',
        arguments: widget.imagesToAnalyze,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Analizando Estructura', style: kTituloPrincipalStyle),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(kNaranjaAcento),
              strokeWidth: 5,
            ),
            const SizedBox(height: 30),
            Text(
              'Analizando imágenes en busca de grietas...',
              textAlign: TextAlign.center,
              style: kTituloPantallaStyle.copyWith(fontSize: 22, color: kAzulPrincipalOscuro),
            ),
            const SizedBox(height: 10),
            Text(
              'Esto puede tomar unos momentos.',
              style: kBodyTextStyle.copyWith(color: kGrisOscuro),
            ),
            const SizedBox(height: 50),
            Icon(Icons.auto_awesome, size: 80, color: kAzulSecundarioClaro.withAlpha((0.7 * 255).round())), // Corrected: using withAlpha
          ],
        ),
      ),
    );
  }
}