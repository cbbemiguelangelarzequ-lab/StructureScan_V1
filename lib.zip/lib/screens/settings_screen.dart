// lib/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Ajustes de la Aplicación', style: kTituloPrincipalStyle),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kBlanco),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.notifications, color: kAzulSecundarioClaro),
                  title: Text('Notificaciones Push', style: kBodyTextStyle),
                  trailing: Switch(
                    value: true, // Example value
                    onChanged: (bool value) {
                      print('Notificaciones: $value');
                      // Update notification settings
                    },
                    activeColor: kNaranjaAcento,
                  ),
                ),
                const Divider(),
                ListTile(
                  leading: Icon(Icons.language, color: kAzulSecundarioClaro),
                  title: Text('Idioma de la Aplicación', style: kBodyTextStyle),
                  subtitle: Text('Español (España)', style: kMiniaturaTextStyle),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kGrisMedio),
                  onTap: () {
                    print('Cambiar Idioma');
                  },
                ),
                const Divider(),
                ListTile(
                  leading: Icon(Icons.brightness_6, color: kAzulSecundarioClaro),
                  title: Text('Modo Oscuro', style: kBodyTextStyle),
                  trailing: Switch(
                    value: false, // Example value
                    onChanged: (bool value) {
                      print('Modo Oscuro: $value');
                      // Toggle dark mode
                    },
                    activeColor: kNaranjaAcento,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Acerca de',
            style: kTituloPantallaStyle.copyWith(fontSize: 18, color: kAzulPrincipalOscuro),
          ),
          const SizedBox(height: 10),
          Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.info_outline, color: kAzulSecundarioClaro),
                  title: Text('Versión de la Aplicación', style: kBodyTextStyle),
                  trailing: Text('1.0.0', style: kMiniaturaTextStyle),
                ),
                const Divider(),
                ListTile(
                  leading: Icon(Icons.policy, color: kAzulSecundarioClaro),
                  title: Text('Política de Privacidad', style: kBodyTextStyle),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kGrisMedio),
                  onTap: () {
                    print('Ver Política de Privacidad');
                  },
                ),
                const Divider(),
                ListTile(
                  leading: Icon(Icons.gavel, color: kAzulSecundarioClaro),
                  title: Text('Términos de Servicio', style: kBodyTextStyle),
                  trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kGrisMedio),
                  onTap: () {
                    print('Ver Términos de Servicio');
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}