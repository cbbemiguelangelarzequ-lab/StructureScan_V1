// lib/screens/pdf_export_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class PdfExportScreen extends StatelessWidget {
  final String reportTitle;
  const PdfExportScreen({super.key, this.reportTitle = 'Informe Detallado'});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Exportar Informe a PDF', style: kTituloPrincipalStyle),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: kBlanco),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.picture_as_pdf, size: 100, color: kRojoAdvertencia),
              const SizedBox(height: 30),
              Text(
                'Preparando el informe "$reportTitle" para exportación...',
                textAlign: TextAlign.center,
                style: kTituloPantallaStyle.copyWith(fontSize: 20, color: kAzulPrincipalOscuro),
              ),
              const SizedBox(height: 20),
              Text(
                'Aquí se mostrará una vista previa o opciones de configuración antes de generar el PDF real. Esto es solo una simulación.',
                textAlign: TextAlign.center,
                style: kBodyTextStyle.copyWith(color: kGrisOscuro),
              ),
              const SizedBox(height: 40),
              ElevatedButton.icon(
                onPressed: () {
                  print('Generar y Descargar PDF para "$reportTitle"');
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Informe PDF generado y descargado! (Simulado)')),
                  );
                  // In a real app, integrate PDF generation library here (e.g., pdf or printing)
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: kVerdeExito,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                icon: const Icon(Icons.download, color: kBlanco),
                label: Text('Generar y Descargar PDF', style: kButtonTextStyle),
              ),
              const SizedBox(height: 15),
              TextButton.icon(
                onPressed: () {
                  print('Compartir Informe "$reportTitle"');
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Compartiendo informe... (Simulado)')),
                  );
                },
                icon: Icon(Icons.share, color: kAzulSecundarioClaro),
                label: Text('Compartir', style: kLinkTextStyle),
              ),
            ],
          ),
        ),
      ),
    );
  }
}