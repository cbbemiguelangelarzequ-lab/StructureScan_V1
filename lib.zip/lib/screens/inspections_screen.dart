// lib/screens/inspections_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class InspectionsScreen extends StatefulWidget {
  const InspectionsScreen({super.key});

  @override
  State<InspectionsScreen> createState() => _InspectionsScreenState();
}

class _InspectionsScreenState extends State<InspectionsScreen> {
  final List<Map<String, String>> _inspections = [
    {
      'name': 'Casa García',
      'date': '2025-06-12',
      'status': 'Completada',
      'location': 'Calle Falsa 123, Cochabamba',
    },
    {
      'name': 'Edificio Central',
      'date': '2025-06-01',
      'status': 'Pendiente de Informe',
      'location': 'Av. Principal, La Paz',
    },
    {
      'name': 'Puente Viejo',
      'date': '2025-05-20',
      'status': 'En Progreso',
      'location': 'Ruta 40, Santa Cruz',
    },
    {
      'name': 'Almacén Industrial',
      'date': '2025-05-10',
      'status': 'Completada',
      'location': 'Zona Industrial, Oruro',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Gestión de Inspecciones', style: kTituloPrincipalStyle),
        actions: [
          IconButton(
            icon: Icon(Icons.add, color: kBlanco),
            onPressed: () {
              print('Crear Nueva Inspección');
              Navigator.of(context).pushNamed('/new_inspection_camera'); // Link to camera
            },
          ),
          IconButton(
            icon: Icon(Icons.filter_list, color: kBlanco),
            onPressed: () {
              print('Filtrar Inspecciones');
              // Implement filter logic
            },
          ),
        ],
      ),
      body: _inspections.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.assignment, size: 80, color: kGrisMedio),
                  SizedBox(height: 20),
                  Text(
                    'No hay inspecciones registradas.',
                    style: kBodyTextStyle.copyWith(color: kGrisMedio),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: _inspections.length,
              itemBuilder: (context, index) {
                final inspection = _inspections[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 8.0),
                  elevation: 3,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          inspection['name']!,
                          style: kTituloPantallaStyle.copyWith(fontSize: 18, color: kAzulPrincipalOscuro),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(Icons.calendar_today, size: 16, color: kGrisMedio),
                            const SizedBox(width: 5),
                            Text('Fecha: ${inspection['date']}', style: kMiniaturaTextStyle),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getStatusColor(inspection['status']!).withAlpha((0.2 * 255).round()),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              child: Text(
                                inspection['status']!,
                                style: kMiniaturaTextStyle.copyWith(
                                  color: _getStatusColor(inspection['status']!),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 5),
                        Row(
                          children: [
                            Icon(Icons.location_on, size: 16, color: kGrisMedio),
                            const SizedBox(width: 5),
                            Expanded(child: Text('Ubicación: ${inspection['location']}', style: kMiniaturaTextStyle)),
                          ],
                        ),
                        const SizedBox(height: 15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextButton(
                              onPressed: () {
                                print('Ver detalles de ${inspection['name']}');
                                // Navigate to a detailed inspection view
                              },
                              child: Text('Ver Detalles', style: kLinkTextStyle),
                            ),
                            const SizedBox(width: 10),
                            ElevatedButton(
                              onPressed: () {
                                print('Editar ${inspection['name']}');
                                // Navigate to edit inspection screen
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: kAzulSecundarioClaro,
                                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              ),
                              child: Text('Editar', style: kButtonTextStyle.copyWith(fontSize: 14)),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          print('Iniciar Nueva Inspección Rápida');
          Navigator.of(context).pushNamed('/new_inspection_camera');
        },
        backgroundColor: kNaranjaAcento,
        icon: const Icon(Icons.camera_alt, color: kBlanco),
        label: Text('Nueva Inspección', style: kButtonTextStyle),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Completada':
        return kVerdeExito;
      case 'Pendiente de Informe':
        return kNaranjaAcento;
      case 'En Progreso':
        return kAzulSecundarioClaro;
      default:
        return kGrisMedio;
    }
  }
}