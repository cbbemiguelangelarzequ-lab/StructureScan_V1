// lib/screens/reports_screen.dart
import 'package:flutter/material.dart';
import 'package:structurescan_app/constants.dart';

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      appBar: AppBar(
        backgroundColor: kAzulPrincipalOscuro,
        title: Text('Informes Técnicos Automatizados', style: kTituloPrincipalStyle),
        leading: Navigator.of(context).canPop()
            ? IconButton(
                icon: const Icon(Icons.arrow_back, color: kBlanco),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              )
            : null,
        actions: [
          IconButton(
            icon: const Icon(Icons.home, color: kBlanco),
            onPressed: () {
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Historial de Informes',
                style: kTituloPantallaStyle.copyWith(fontSize: 20, color: kAzulPrincipalOscuro),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: 5, // Simulación de 5 informes
              itemBuilder: (context, index) {
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: ListTile(
                    leading: Icon(Icons.description, color: kAzulSecundarioClaro, size: 30),
                    title: Text('Informe de Inspección #${index + 1}', style: kBodyTextStyle.copyWith(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Fecha: 2025-06-${15 - index}', style: kMiniaturaTextStyle),
                        Text('Estado: Completado', style: kMiniaturaTextStyle.copyWith(color: kVerdeExito)),
                      ],
                    ),
                    trailing: Icon(Icons.arrow_forward_ios, size: 16, color: kGrisMedio),
                    onTap: () {
                      print('Ver detalles del Informe #${index + 1}');
                      Navigator.of(context).pushNamed('/pdf_export_screen', arguments: 'Informe de Inspección #${index + 1}');
                    },
                  ),
                );
              },
            ),
          ),
          // MODIFICACIÓN: Envolver los botones en un Row
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Distribuye los botones equitativamente
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      print('Volver al Menú Principal');
                      // Navega al Dashboard, limpiando la pila hasta la primera ruta
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kAzulSecundarioClaro, // Un color diferente para distinguirlo
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      // Removido minimumSize para que Expanded gestione el ancho
                    ),
                    icon: const Icon(Icons.menu, color: kBlanco), // Un icono de menú o flecha
                    label: Text('Ir al Menú', style: kButtonTextStyle.copyWith(fontSize: 14)), // Texto más corto
                  ),
                ),
                const SizedBox(width: 15), // Espacio entre los botones
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      print('Generar Nuevo Informe - Navegando a la cámara de inspección');
                      Navigator.of(context).pushNamed('/new_inspection_camera');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kNaranjaAcento,
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      // Removido minimumSize para que Expanded gestione el ancho
                    ),
                    icon: const Icon(Icons.add, color: kBlanco),
                    label: Text('Generar Nuevo Informe', style: kButtonTextStyle.copyWith(fontSize: 14)), // Texto más corto
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}