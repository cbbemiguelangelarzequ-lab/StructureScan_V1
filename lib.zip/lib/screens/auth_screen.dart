// lib/screens/auth_screen.dart
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart'; // Importa Supabase
import 'package:structurescan_app/constants.dart'; // Asegúrate de que tus constantes estén importadas
// Importa el paquete intl para formatear fechas
import 'package:intl/intl.dart';

// Eliminado: import 'package:structurescan_app/screens/dashboard_screen.dart'; // Si no se usa directamente aquí

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true; // true para Login, false para Registro
  bool _isLoading = false; // Para mostrar un indicador de carga
  String? _selectedUserType; // Para el tipo de usuario en el registro

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();

  // Acceso a la instancia de Supabase Client (asumiendo que está inicializada en main.dart)
  final supabase = Supabase.instance.client;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _fullNameController.dispose();
    super.dispose();
  }

  // Función para mostrar mensajes al usuario
  void _showMessage(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? kRojoAdvertencia : kAzulPrincipalOscuro,
        duration: const Duration(seconds: 3), // Duración del SnackBar
      ),
    );
  }

  // Función para registrar un nuevo usuario con Supabase
  Future<void> _signUp() async {
    // Validaciones básicas de campos
    if (_emailController.text.isEmpty ||
        _passwordController.text.isEmpty ||
        _fullNameController.text.isEmpty ||
        !_emailController.text.contains('@')) {
      _showMessage('Por favor, completa todos los campos y usa un email válido.', isError: true);
      return;
    }
    if (_passwordController.text != _confirmPasswordController.text) {
      _showMessage('Las contraseñas no coinciden.', isError: true);
      return;
    }
    if (_selectedUserType == null) {
      _showMessage('Por favor, selecciona tu tipo de usuario.', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // 1. Registrar usuario en Supabase Auth
      final AuthResponse res = await supabase.auth.signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        // Puedes pasar metadatos del usuario al momento del registro
        data: {
          'full_name': _fullNameController.text.trim(),
          'user_type': _selectedUserType,
        },
      );

      // Comprobamos si el registro en auth fue exitoso
      if (res.user != null) {
        // Formatear la fecha para evitar el error 'Invalid input syntax for type timestamp with time zone'
        // Usamos toUtc() para la consistencia horaria y DateFormat para la precisión
        final String formattedDate = DateFormat("yyyy-MM-ddTHH:mm:ss.SSS'Z'").format(DateTime.now().toUtc());

        // Opcional: Insertar datos adicionales del perfil en una tabla 'profiles'
        await supabase.from('profiles').insert({
          'id': res.user!.id, // El UID del usuario de Supabase Auth
          'full_name': _fullNameController.text.trim(),
          'email': _emailController.text.trim(),
          'user_type': _selectedUserType,
          'created_at': formattedDate, // Usamos la fecha formateada
        });

        // Si la confirmación de email está deshabilitada en Supabase, el usuario inicia sesión directamente.
        // Si está habilitada, res.user será no nulo, pero requerirá confirmación.
        // Se asume que res.user no es nulo si el registro fue exitoso en Auth.
        _showMessage('Registro exitoso. ¡Bienvenido, ${res.user!.email}!', isError: false);
        _navigateToDashboard(); // Navegar al Dashboard después de un registro exitoso y perfil insertado
      } else {
        // Esto se ejecuta si el registro en Auth es exitoso, pero se requiere confirmación de email
        // y no hay un usuario inmediatamente disponible para iniciar sesión o se redirige a una pantalla de confirmación.
        // Verifica tu configuración de "Enable email confirmations" en Supabase.
        _showMessage('Registro exitoso. Por favor, verifica tu correo electrónico para confirmar tu cuenta.', isError: false);
        // Puedes agregar aquí una navegación a una pantalla que informe al usuario que debe verificar su email.
      }
    } on AuthException catch (e) {
      _showMessage('Error de registro: ${e.message}', isError: true);
    } catch (e) {
      _showMessage('Ocurrió un error inesperado durante el registro: $e', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Función para iniciar sesión con Supabase
  Future<void> _signIn() async {
    // Validaciones básicas de campos
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      _showMessage('Por favor, introduce tu correo y contraseña.', isError: true);
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final AuthResponse res = await supabase.auth.signInWithPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      if (res.user != null) {
        _showMessage('Inicio de sesión exitoso. ¡Bienvenido de nuevo, ${res.user!.email}!', isError: false);
        _navigateToDashboard();
      } else {
        // Este caso es menos común si AuthException no se lanza,
        // pero cubre escenarios donde el usuario podría ser nulo sin una excepción explícita.
        _showMessage('Credenciales inválidas. Por favor, verifica tu email y contraseña.', isError: true);
      }
    } on AuthException catch (e) {
      _showMessage('Error al iniciar sesión: ${e.message}', isError: true);
    } catch (e) {
      _showMessage('Ocurrió un error inesperado al iniciar sesión: $e', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Función para navegar al dashboard
  void _navigateToDashboard() {
    Navigator.of(context).pushReplacementNamed('/dashboard');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kGrisClaro,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/structurescan_logo.png', // Asegúrate de que esta ruta sea correcta
                width: 120,
                height: 120,
              ),
              const SizedBox(height: 30),
              Card(
                color: kBlanco,
                elevation: 5,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(25.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _isLogin ? 'Iniciar Sesión' : 'Crear Cuenta',
                        style: kTituloPantallaStyle.copyWith(fontSize: 28),
                      ),
                      const SizedBox(height: 30),
                      TextFormField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          labelText: 'Correo Electrónico',
                          labelStyle: kBodyTextStyle.copyWith(color: kGrisMedio),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: kGrisMedio),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: kAzulSecundarioClaro, width: 2),
                          ),
                        ),
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _passwordController,
                        decoration: InputDecoration(
                          labelText: 'Contraseña',
                          labelStyle: kBodyTextStyle.copyWith(color: kGrisMedio),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: kGrisMedio),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: const BorderSide(color: kAzulSecundarioClaro, width: 2),
                          ),
                          suffixIcon: const Icon(Icons.visibility_off, color: kGrisMedio), // Puedes implementar alternar visibilidad
                        ),
                        obscureText: true,
                      ),
                      const SizedBox(height: 20),

                      if (!_isLogin) ...[ // Campos adicionales para REGISTRO
                        TextFormField(
                          controller: _fullNameController,
                          decoration: InputDecoration(
                            labelText: 'Nombre Completo',
                            labelStyle: kBodyTextStyle.copyWith(color: kGrisMedio),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kGrisMedio),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kAzulSecundarioClaro, width: 2),
                            ),
                          ),
                          keyboardType: TextInputType.name,
                        ),
                        const SizedBox(height: 20),
                        TextFormField(
                          controller: _confirmPasswordController,
                          decoration: InputDecoration(
                            labelText: 'Confirmar Contraseña',
                            labelStyle: kBodyTextStyle.copyWith(color: kGrisMedio),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kGrisMedio),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kAzulSecundarioClaro, width: 2),
                            ),
                            suffixIcon: const Icon(Icons.visibility_off, color: kGrisMedio),
                          ),
                          obscureText: true,
                        ),
                        const SizedBox(height: 20),
                        DropdownButtonFormField<String>(
                          decoration: InputDecoration(
                            labelText: 'Tipo de Usuario',
                            labelStyle: kBodyTextStyle.copyWith(color: kGrisMedio),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kGrisMedio),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(color: kAzulSecundarioClaro, width: 2),
                            ),
                          ),
                          items: const [
                            DropdownMenuItem(value: 'Propietario', child: Text('Propietario de Vivienda')),
                            DropdownMenuItem(value: 'Constructor', child: Text('Constructor')),
                            DropdownMenuItem(value: 'Ingeniero', child: Text('Ingeniero Civil/Arquitecto')),
                            DropdownMenuItem(value: 'Administrador', child: Text('Administrador')),
                          ],
                          onChanged: (String? newValue) {
                            setState(() {
                              _selectedUserType = newValue;
                            });
                          },
                          value: _selectedUserType, // Usar el valor seleccionado por el estado
                          hint: Text('Selecciona tu tipo de usuario', style: kBodyTextStyle.copyWith(color: kGrisMedio)),
                        ),
                        const SizedBox(height: 20),
                      ],

                      _isLoading
                          ? const CircularProgressIndicator(color: kAzulPrincipalOscuro)
                          : SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: _isLogin ? _signIn : _signUp, // Llama a las funciones Supabase
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: kAzulPrincipalOscuro,
                                  padding: const EdgeInsets.symmetric(vertical: 15),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: Text(
                                  _isLogin ? 'INICIAR SESIÓN' : 'REGISTRARSE',
                                  style: kButtonTextStyle,
                                ),
                              ),
                            ),
                      const SizedBox(height: 10),

                      if (_isLogin)
                        TextButton(
                          onPressed: () {
                            // TODO: Implementar lógica para olvidar contraseña con Supabase
                            // Puedes usar supabase.auth.resetPasswordForEmail()
                            _showMessage('Funcionalidad de "Olvidaste tu contraseña" pendiente de implementar.', isError: false);
                          },
                          child: Text('¿Olvidaste tu contraseña?', style: kLinkTextStyle),
                        ),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _isLogin = !_isLogin;
                            // Limpiar campos al cambiar de modo
                            _emailController.clear();
                            _passwordController.clear();
                            _confirmPasswordController.clear();
                            _fullNameController.clear();
                            _selectedUserType = null; // Resetear tipo de usuario
                          });
                        },
                        child: Text(
                          _isLogin ? '¿No tienes una cuenta? Regístrate' : '¿Ya tienes una cuenta? Iniciar Sesión',
                          style: kLinkTextStyle,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}